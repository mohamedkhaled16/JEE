/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.school.services;

import com.school.models.Instructor;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContexts;
import javax.persistence.TypedQuery;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 *
 * @author mohamedk
 */
@Stateless
public class InstructorService {

    @PersistenceContext(unitName = "ProjectPU")
    private EntityManager em;
    public void addInstructor (Instructor instructor) {
        em.persist(instructor);
        
    }
    public List<Instructor> listInstructor(){
    
       TypedQuery<Instructor> sQuery = em.createQuery("select s from Instructor s ",Instructor.class);
         List<Instructor>  sList =sQuery.getResultList();
         return sList;
    }
    public void updateInstructor(Instructor s){
    TypedQuery<Instructor> sQuery = em.createNamedQuery("Instructor.updateById",Instructor.class);
    sQuery.setParameter("fname", s.getFname());
    sQuery.setParameter("lname", s.getLname());
    sQuery.setParameter("email", s.getEmail());
    sQuery.setParameter("age", s.getAge());
    sQuery.setParameter("dob", s.getDob());
    sQuery.setParameter("file", s.getFile());
    sQuery.setParameter("gender", s.getGender());
    sQuery.setParameter("interest", s.getInterest());
    sQuery.setParameter("id", s.getId());
    sQuery.executeUpdate();
    }
    public Instructor getInstructor(int id){
    TypedQuery<Instructor> sQuery = em.createNamedQuery("Instructor.getById",Instructor.class);
    sQuery.setParameter("id", id);
    return  sQuery.getSingleResult();
        
    }

    public void deleteInstructor(int id){
    Instructor s = em.find(Instructor.class, id);
    em.remove(s);    
    }
    
}
