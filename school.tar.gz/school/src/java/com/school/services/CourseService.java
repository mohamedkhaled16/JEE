/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.school.services;

import com.school.models.Course;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContexts;
import javax.persistence.TypedQuery;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 *
 * @author mohamedk
 */
@Stateless
public class CourseService {

    @PersistenceContext(unitName = "ProjectPU")
    private EntityManager em;
    public void addCourse (Course course) {
        em.persist(course);
        
    }
    public List<Course> listCourse(){
    
       TypedQuery<Course> sQuery = em.createQuery("select s from Course s ",Course.class);
         List<Course>  sList =sQuery.getResultList();
         return sList;
    }
    public void updateCourse(Course s){
    TypedQuery<Course> sQuery = em.createNamedQuery("Course.updateById",Course.class);
    sQuery.setParameter("fname", s.getFname());
    sQuery.setParameter("lname", s.getLname());
    sQuery.setParameter("email", s.getEmail());
    sQuery.setParameter("age", s.getAge());
    sQuery.setParameter("dob", s.getDob());
    sQuery.setParameter("file", s.getFile());
    sQuery.setParameter("gender", s.getGender());
    sQuery.setParameter("interest", s.getInterest());
    sQuery.setParameter("id", s.getId());
    sQuery.executeUpdate();
    }
    public Course getCourse(int id){
    TypedQuery<Course> sQuery = em.createNamedQuery("Course.getById",Course.class);
    sQuery.setParameter("id", id);
    return  sQuery.getSingleResult();
        
    }

    public void deleteCourse(int id){
    Course s = em.find(Course.class, id);
    em.remove(s);    
    }
    
}
